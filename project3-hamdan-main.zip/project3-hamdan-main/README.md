# Project 3
In this project, a chat application was implemented using SocketIO javascript client and Flask Socket IO server. The design is made using Bootstrap and UI interaction is implemented with Javascript. 

As a personal touch, I added the feature to allow users to delete his/her message from the channel.

## Files
1. ```application.py``` - Runs the server-side of the application and the SocketIO endpoint.
2. ```templates/index.html``` - Runs the client-side of the application as an html file.
3. ```requirements.txt``` - Lists the required python libraries to run the code. 

## Setup
Before running the application, make sure to install the required libraries first. The following command can be used to install these.

```cmd
pip3 install -r requirements.txt
```

## Start-Up
To run the application, just execute the following command.
```cmd
python3 application.py
```